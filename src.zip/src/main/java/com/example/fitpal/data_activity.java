package com.example.fitpal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.widget.Button;
import android.text.Editable;
import android.widget.ImageButton;
//import android.widget.TextView;
import android.widget.EditText;
import android.view.View;
//import android.content.Intent;
import java.nio.file.Files;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.Random;

public class data_activity extends AppCompatActivity {

    //String gender;
    String h;
    String w;
    String a;

    EditText height;
    EditText weight;
    EditText age;

    ImageButton backb;
    ArrayList<String> data;

    String bmr;
    double bmr_num;
    int h_num;
    int w_num;
    int a_num;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_activity);

        height = findViewById(R.id.height_input);
        weight = findViewById(R.id.weight_input);
        age = findViewById(R.id.age_input);
        backb = findViewById(R.id.back);

        //FileManager manager = new FileManager("test.txt");
        //File dir = getApplicationContext().getFilesDir();


        data = new ArrayList<>();

        backb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                if((h != null)&&(w != null)&&(h != null) ) {
                    FileManager manager = new FileManager("test.txt");
                    File dir = getApplicationContext().getFilesDir();

                    if (height.getText() != null) {
                        h = height.getText().toString();
                        data.add(h);
                        h_num = Integer.parseInt(h);
                    }
                    if (weight.getText() != null) {
                        w = weight.getText().toString();
                        data.add(w);
                        w_num = Integer.parseInt(w);
                    }
                    if (age.getText() != null) {
                        a = age.getText().toString();
                        data.add(a);
                        a_num = Integer.parseInt(a);
                    }
                    if (bmr != null) {
                        String line = basic(w_num, h_num, a_num);
                        data.add(bmr);
                    }
                    manager.save(data, dir);

                    finish();
                }else{
                    finish();
                }

            }
        });

/*
        data.add("this");
        data.add("is");
        data.add("a");
        data.add("test");
*/
        //manager.save(data, dir);
/*
        if (height.getText() != null){
            h = height.getText().toString();
            //data.add(h);
            h_num = Integer.parseInt(h);
        }
        if (weight.getText() != null){
            w = weight.getText().toString();
            //data.add(w);
            w_num = Integer.parseInt(w);
        }
        if (age.getText() != null){
            a = age.getText().toString();
           //data.add(a);
            a_num = Integer.parseInt(a);
        }
        if (bmr != null) {
            //data.add(bmr);
        }
*/
       //manager.save(data, dir);

    }

    public void radioclick(View view){

        if( view.getId() == R.id.FButton) {
            data.add("f");
            bmr_num = 655 + (4.35 * w_num) + (4.7 * h_num) - (4.7 * a_num);
            bmr = String.valueOf(bmr_num);
            data.add(bmr);

        }else {
            data.add("m");
            bmr_num = 66 + (6.23 * w_num) + (12.7 * h_num) - (6.8 * a_num);
            bmr = String.valueOf(bmr_num);
            data.add(bmr);
        }
    }
    public String basic (int wei, int hei, int ag){
        bmr_num = 66 + (6.23 * wei) + (12.7 * hei) - (6.8 * ag);
        bmr = String.valueOf(bmr_num);
        return bmr;
    }
}
