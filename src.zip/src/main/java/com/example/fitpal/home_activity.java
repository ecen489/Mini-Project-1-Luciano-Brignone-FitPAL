package com.example.fitpal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.widget.Button;
import android.text.Editable;
import android.widget.ImageButton;
//import android.widget.TextView;
import android.widget.EditText;
import android.view.View;
//import android.content.Intent;
import java.nio.file.Files;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.Random;

public class home_activity extends AppCompatActivity {

    TextView BMR;
    double bmr_dis;
    TextView fat;
    TextView carb;
    TextView protein;
    ImageButton backb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_activity);

        BMR = findViewById(R.id.view_bmr);
        fat = findViewById(R.id.fat_view);
        carb = findViewById(R.id.carbs_view);
        protein  = findViewById(R.id.protein_view);
        backb = findViewById(R.id.imageButton);

        FileManager manager = new FileManager("test.txt");
        File dir = getApplicationContext().getFilesDir();
        ArrayList<String> newdata = manager.read(dir);

        bmr_dis = Double.parseDouble(newdata.get(5));
        int weight = Integer.parseInt(newdata.get(3));
        int fats = (int)((bmr_dis * 0.2)/9.0);
        int carbs = (int)(((bmr_dis * 0.2) + (weight * 4.0))/4.0);

        BMR.setText("BMR: " + bmr_dis);
        fat.setText("Fat: " + fats);
        carb.setText("Carb: " + carbs);
        protein.setText("Protein: " + weight);

        backb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                finish();
            }
        });

    }
}
