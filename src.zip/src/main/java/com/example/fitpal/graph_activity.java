package com.example.fitpal;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class graph_activity extends AppCompatActivity {

    ImageButton backb;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_activity);

        backb = findViewById(R.id.imageButton);

        GraphView graph = (GraphView) findViewById(R.id.graph);
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(0, 156),
                new DataPoint(1, 155.4),
                new DataPoint(2, 155.2),
                new DataPoint(3, 155.1),
                new DataPoint(4, 154.3),
                new DataPoint(5, 154.8),
                new DataPoint(6, 154.1),
                new DataPoint(7, 153.7),

        });
        graph.addSeries(series);


        backb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                finish();
            }
        });
    }
}
