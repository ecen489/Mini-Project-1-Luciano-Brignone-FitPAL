package com.example.fitpal;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;

public class FileManager {

    private String filename = "";

    public FileManager(String name) {
        filename = name;
    }

    public ArrayList<String> read(File dir) {
        ArrayList<String> data = new ArrayList<>();
        BufferedReader reader = null;
        File file = new File(dir, filename);
        if (file.exists()) {
            try {
                reader = new BufferedReader(new FileReader(file));
                String line = reader.readLine();
                data.add(line);
                while (line != null) {
                    line = reader.readLine();
                    if (line != null) data.add(line);
                }

            } catch (IOException e) {
                e.printStackTrace();

            } finally {
                try {
                    if (reader != null)
                        reader.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

        }

        return data;
    }

    public void save(ArrayList<String> data, File dir) {
        File file = new File(dir, filename);
        FileWriter writer = null;
        boolean append = false;
        try {
            writer = new FileWriter(file, append);
            for (String line : data) {
                writer.write(line + "\n");
            }
            writer.flush();

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null)
                    writer.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }


    }
}